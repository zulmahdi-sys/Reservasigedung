
import React from 'react';
// Correctly import Settings from types.ts
import { Settings as SettingsType } from '../types.ts';

interface SettingsProps {
  settings: SettingsType;
  setSettings: (settings: SettingsType) => void;
}

const Settings: React.FC<SettingsProps> = ({ settings, setSettings }) => {
  return (
    <div className="max-w-4xl mx-auto pt-12 pb-32 px-6">
      <header className="mb-12">
        <h1 className="text-3xl font-bold text-slate-900">Integrations</h1>
        <p className="text-slate-500">Connect your landing page to your Google account for automated storage.</p>
      </header>

      <div className="space-y-8">
        <section className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 bg-green-50 text-green-600 rounded-xl flex items-center justify-center text-xl">
              <i className="fas fa-table"></i>
            </div>
            <div>
              <h2 className="text-xl font-bold">Google Sheets</h2>
              <p className="text-slate-400 text-sm">Where all your lead data will be appended.</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Google Apps Script URL (Webhook)</label>
              <input
                type="text"
                // Fixed: replaced incorrect 'webhookUrl' with 'googleSheetWebhook'
                value={settings.googleSheetWebhook}
                onChange={(e) => setSettings({...settings, googleSheetWebhook: e.target.value})}
                placeholder="https://script.google.com/macros/s/..."
                className="w-full p-4 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-green-500"
              />
              <p className="text-xs text-slate-400 mt-2">Paste your Google Apps Script URL here to enable automatic lead syncing.</p>
            </div>
          </div>
        </section>

        <section className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center text-xl">
              <i className="fas fa-hdd"></i>
            </div>
            <div>
              <h2 className="text-xl font-bold">Google Drive Storage</h2>
              <p className="text-slate-400 text-sm">Save landing page assets and exports.</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">Target Folder ID</label>
              <input
                type="text"
                // Fixed: replaced incorrect 'googleDriveFolder' with 'googleDriveFolderId'
                value={settings.googleDriveFolderId}
                onChange={(e) => setSettings({...settings, googleDriveFolderId: e.target.value})}
                placeholder="e.g. 1a2b3c4d5e6f7g8h9i0j"
                className="w-full p-4 rounded-xl border border-slate-200 outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <button className="text-blue-600 font-bold flex items-center gap-2 hover:underline">
              <i className="fas fa-plus"></i> Create new folder in Drive
            </button>
          </div>
        </section>

        <section className="bg-slate-900 text-white p-8 rounded-3xl">
          <h3 className="text-lg font-bold mb-4">How to set up?</h3>
          <ul className="space-y-3 text-slate-400 text-sm">
            <li className="flex gap-3">
              <span className="bg-white/10 w-6 h-6 flex items-center justify-center rounded-full text-white text-[10px] font-bold shrink-0">1</span>
              <span>Create a new Google Sheet.</span>
            </li>
            <li className="flex gap-3">
              <span className="bg-white/10 w-6 h-6 flex items-center justify-center rounded-full text-white text-[10px] font-bold shrink-0">2</span>
              <span>Go to Extensions {'>'} Apps Script.</span>
            </li>
            <li className="flex gap-3">
              <span className="bg-white/10 w-6 h-6 flex items-center justify-center rounded-full text-white text-[10px] font-bold shrink-0">3</span>
              <span>Paste the provided Webhook Script and deploy as Web App.</span>
            </li>
            <li className="flex gap-3">
              <span className="bg-white/10 w-6 h-6 flex items-center justify-center rounded-full text-white text-[10px] font-bold shrink-0">4</span>
              <span>Paste the deployment URL above.</span>
            </li>
          </ul>
        </section>
      </div>
    </div>
  );
};

export default Settings;
