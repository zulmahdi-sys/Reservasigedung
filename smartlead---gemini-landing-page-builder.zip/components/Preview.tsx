
import React, { useState } from 'react';
import { Building, ScheduleItem, Booking } from '../types.ts';

interface PreviewProps {
  buildings: Building[];
  schedules: ScheduleItem[];
  onBook: (booking: Booking) => void;
}

const Preview: React.FC<PreviewProps> = ({ buildings, schedules, onBook }) => {
  const [selectedBuilding, setSelectedBuilding] = useState<Building | null>(null);
  const [bookingForm, setBookingForm] = useState({ name: '', email: '', date: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBuilding) return;
    setIsSubmitting(true);
    
    // Fixed: Ensure a complete Booking object with a unique ID is created
    const newBooking: Booking = {
      id: Date.now().toString(),
      customerName: bookingForm.name,
      customerEmail: bookingForm.email,
      buildingName: selectedBuilding.name,
      bookingDate: bookingForm.date,
      timestamp: new Date().toLocaleString(),
      status: 'Pending'
    };

    await new Promise(r => setTimeout(r, 1000)); // Simulating sync
    onBook(newBooking);
    setIsSubmitting(false);
    setSelectedBuilding(null);
    setBookingForm({ name: '', email: '', date: '' });
    alert("Pemesanan berhasil! Data telah disinkronkan ke Google Sheets.");
  };

  return (
    <div className="bg-slate-50 min-h-screen pb-32">
      {/* Hero */}
      <section className="bg-white border-b border-slate-200 py-20 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-5xl font-black text-slate-900 mb-4 tracking-tight">Sistem Reservasi Gedung</h1>
          <p className="text-slate-500 text-xl max-w-2xl mx-auto">
            Cek ketersediaan gedung secara real-time. Semua data terupdate otomatis ke Google Drive dan Google Sheets.
          </p>
        </div>
      </section>

      {/* Building Grid */}
      <section className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {buildings.map(building => {
            const buildingSchedules = schedules.filter(s => s.buildingId === building.id);
            return (
              <div key={building.id} className="bg-white rounded-3xl overflow-hidden shadow-sm border border-slate-100 hover:shadow-xl transition-all flex flex-col">
                <div className="h-56 relative">
                  <img src={building.imageUrl} alt={building.name} className="w-full h-full object-cover" />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-blue-600 shadow-sm">
                    {building.capacity} Kursi
                  </div>
                </div>
                <div className="p-6 flex-grow">
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">{building.name}</h3>
                  <p className="text-slate-500 text-sm mb-6 line-clamp-2">{building.description}</p>
                  
                  <div className="space-y-3 mb-8">
                    <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest">Jadwal Terdekat</h4>
                    {buildingSchedules.slice(0, 3).map(s => (
                      <div key={s.id} className="flex justify-between items-center text-sm">
                        <span className="text-slate-600 font-medium">{s.date}</span>
                        <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                          s.status === 'Available' ? 'bg-green-100 text-green-700' : 
                          s.status === 'Booked' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                        }`}>
                          {s.status}
                        </span>
                      </div>
                    ))}
                  </div>

                  <button 
                    onClick={() => setSelectedBuilding(building)}
                    className="w-full bg-slate-900 text-white py-3 rounded-xl font-bold hover:bg-blue-600 transition-colors"
                  >
                    Pesan Sekarang
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Booking Modal */}
      {selectedBuilding && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-6">
          <div className="bg-white rounded-[2rem] w-full max-w-md p-8 shadow-2xl animate-in fade-in zoom-in duration-200">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">Pesan {selectedBuilding.name}</h2>
              <button onClick={() => setSelectedBuilding(null)} className="text-slate-400 hover:text-slate-600">
                <i className="fas fa-times text-xl"></i>
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-2 uppercase">Nama Lengkap</label>
                <input 
                  required
                  type="text" 
                  className="w-full p-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder="Budi Santoso"
                  value={bookingForm.name}
                  onChange={e => setBookingForm({...bookingForm, name: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-2 uppercase">Email Aktif</label>
                <input 
                  required
                  type="email" 
                  className="w-full p-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder="budi@example.com"
                  value={bookingForm.email}
                  onChange={e => setBookingForm({...bookingForm, email: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-2 uppercase">Tanggal Pemakaian</label>
                <input 
                  required
                  type="date" 
                  className="w-full p-4 rounded-xl border border-slate-200 focus:ring-2 focus:ring-blue-500 outline-none"
                  value={bookingForm.date}
                  onChange={e => setBookingForm({...bookingForm, date: e.target.value})}
                />
              </div>
              <button 
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-blue-700 transition-all flex items-center justify-center gap-2"
              >
                {isSubmitting ? <i className="fas fa-circle-notch fa-spin"></i> : <i className="fas fa-paper-plane"></i>}
                Kirim Reservasi
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Preview;
