
import React, { useState } from 'react';
import { generateBuildingDescription } from '../services/geminiService.ts';
import { Building, ScheduleItem } from '../types.ts';

interface BuilderProps {
  buildings: Building[];
  setBuildings: (b: Building[]) => void;
  schedules: ScheduleItem[];
  setSchedules: (s: ScheduleItem[]) => void;
}

const Builder: React.FC<BuilderProps> = ({ buildings, setBuildings, schedules, setSchedules }) => {
  const [loadingAi, setLoadingAi] = useState<string | null>(null);

  const handleAiDescription = async (building: Building) => {
    setLoadingAi(building.id);
    try {
      const desc = await generateBuildingDescription(building.name, "Tempat Pertemuan");
      setBuildings(buildings.map(b => b.id === building.id ? { ...b, description: desc } : b));
    } finally {
      setLoadingAi(null);
    }
  };

  const addSchedule = (buildingId: string) => {
    const newItem: ScheduleItem = {
      id: Date.now().toString(),
      buildingId,
      date: new Date().toISOString().split('T')[0],
      status: 'Available'
    };
    setSchedules([...schedules, newItem]);
  };

  return (
    <div className="max-w-5xl mx-auto pt-12 pb-32 px-6">
      <header className="mb-12">
        <h1 className="text-4xl font-black text-slate-900">Kelola Gedung & Jadwal</h1>
        <p className="text-slate-500 mt-2">Update status ketersediaan yang tersinkron dengan Google Drive.</p>
      </header>

      <div className="space-y-12">
        {buildings.map(building => (
          <div key={building.id} className="bg-white rounded-3xl border border-slate-100 shadow-sm p-8">
            <div className="flex flex-col lg:flex-row gap-8">
              <div className="lg:w-1/3">
                <img src={building.imageUrl} alt="" className="w-full h-48 object-cover rounded-2xl mb-4" />
                <button 
                  onClick={() => handleAiDescription(building)}
                  className="w-full py-2 bg-blue-50 text-blue-600 rounded-lg text-sm font-bold flex items-center justify-center gap-2 hover:bg-blue-100 transition-colors"
                >
                  {loadingAi === building.id ? <i className="fas fa-circle-notch fa-spin"></i> : <i className="fas fa-magic"></i>}
                  AI Rewrite Deskripsi
                </button>
              </div>
              
              <div className="flex-grow">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-slate-900">{building.name}</h2>
                    <p className="text-slate-400 text-sm">ID: {building.id}</p>
                  </div>
                  <button 
                    onClick={() => addSchedule(building.id)}
                    className="bg-slate-900 text-white px-4 py-2 rounded-lg text-xs font-bold hover:bg-blue-600"
                  >
                    + Tambah Jadwal
                  </button>
                </div>

                <div className="space-y-4">
                  {schedules.filter(s => s.buildingId === building.id).map(s => (
                    <div key={s.id} className="flex flex-wrap items-center gap-4 p-4 bg-slate-50 rounded-xl border border-slate-100">
                      <input 
                        type="date" 
                        value={s.date}
                        onChange={(e) => setSchedules(schedules.map(item => item.id === s.id ? {...item, date: e.target.value} : item))}
                        className="bg-transparent font-semibold outline-none" 
                      />
                      <select 
                        value={s.status}
                        onChange={(e) => setSchedules(schedules.map(item => item.id === s.id ? {...item, status: e.target.value as any} : item))}
                        className="bg-white px-3 py-1 rounded-md text-xs font-bold shadow-sm outline-none"
                      >
                        <option value="Available">Available</option>
                        <option value="Booked">Booked</option>
                        <option value="Maintenance">Maintenance</option>
                      </select>
                      <input 
                        type="text"
                        placeholder="Catatan..."
                        value={s.notes || ''}
                        onChange={(e) => setSchedules(schedules.map(item => item.id === s.id ? {...item, notes: e.target.value} : item))}
                        className="flex-grow bg-transparent text-sm italic text-slate-500 outline-none"
                      />
                      <button 
                        onClick={() => setSchedules(schedules.filter(item => item.id !== s.id))}
                        className="text-red-400 hover:text-red-600"
                      >
                        <i className="fas fa-trash"></i>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Builder;
