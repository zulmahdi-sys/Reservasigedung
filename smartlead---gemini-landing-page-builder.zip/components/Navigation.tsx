
import React from 'react';
import { ViewMode } from '../types.ts';

interface NavigationProps {
  currentView: ViewMode;
  setView: (view: ViewMode) => void;
  isLoggedIn: boolean;
  onLogout: () => void;
}

const Navigation: React.FC<NavigationProps> = ({ currentView, setView, isLoggedIn, onLogout }) => {
  const publicLinks = [
    { id: ViewMode.LANDING, label: 'Home', icon: 'fa-home' },
  ];

  const adminLinks = [
    { id: ViewMode.SCHEDULE_MANAGER, label: 'Schedule', icon: 'fa-calendar-alt' },
    { id: ViewMode.BOOKINGS, label: 'Orders', icon: 'fa-clipboard-list' },
    { id: ViewMode.SETTINGS, label: 'Sync', icon: 'fa-sync' },
  ];

  return (
    <nav className="fixed bottom-6 left-1/2 -translate-x-1/2 bg-white/90 backdrop-blur-xl border border-slate-200 px-6 py-3 rounded-2xl shadow-2xl z-50 flex gap-6 items-center">
      {publicLinks.map((link) => (
        <button
          key={link.id}
          onClick={() => setView(link.id)}
          className={`flex flex-col items-center gap-1 transition-all ${
            currentView === link.id ? 'text-blue-600 scale-110' : 'text-slate-400 hover:text-slate-600'
          }`}
        >
          <i className={`fas ${link.icon} text-lg`}></i>
          <span className="text-[10px] font-bold uppercase tracking-tighter">{link.label}</span>
        </button>
      ))}

      {isLoggedIn ? (
        <>
          <div className="w-px h-8 bg-slate-200 mx-2"></div>
          {adminLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => setView(link.id)}
              className={`flex flex-col items-center gap-1 transition-all ${
                currentView === link.id ? 'text-blue-600 scale-110' : 'text-slate-400 hover:text-slate-600'
              }`}
            >
              <i className={`fas ${link.icon} text-lg`}></i>
              <span className="text-[10px] font-bold uppercase tracking-tighter">{link.label}</span>
            </button>
          ))}
          <button
            onClick={onLogout}
            className="flex flex-col items-center gap-1 text-slate-400 hover:text-red-500 transition-all"
          >
            <i className="fas fa-sign-out-alt text-lg"></i>
            <span className="text-[10px] font-bold uppercase tracking-tighter">Exit</span>
          </button>
        </>
      ) : (
        <button
          onClick={() => setView(ViewMode.BOOKINGS)} // Dashboard requires login
          className="flex flex-col items-center gap-1 text-slate-400 hover:text-slate-900 transition-all border-l border-slate-200 pl-6"
        >
          <i className="fas fa-lock text-lg"></i>
          <span className="text-[10px] font-bold uppercase tracking-tighter">Admin</span>
        </button>
      )}
    </nav>
  );
};

export default Navigation;
