
import React from 'react';
// Explicitly import Lead from types.ts to resolve missing export error
import { Lead } from '../types.ts';

interface DashboardProps {
  leads: Lead[];
}

const Dashboard: React.FC<DashboardProps> = ({ leads }) => {
  return (
    <div className="max-w-6xl mx-auto pt-12 pb-32 px-6">
      <header className="flex justify-between items-center mb-12">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Leads & Submissions</h1>
          <p className="text-slate-500">Real-time data synced with your Google ecosystem.</p>
        </div>
        <div className="flex gap-3">
          <button className="bg-white border border-slate-200 px-4 py-2 rounded-lg font-semibold flex items-center gap-2 hover:bg-slate-50 transition-all shadow-sm">
            <i className="fas fa-file-export text-green-600"></i> Export to Sheet
          </button>
          <button className="bg-white border border-slate-200 px-4 py-2 rounded-lg font-semibold flex items-center gap-2 hover:bg-slate-50 transition-all shadow-sm">
            <i className="fas fa-folder-open text-blue-600"></i> Open Drive
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
          <div className="text-slate-400 text-xs font-bold uppercase mb-2">Total Leads</div>
          <div className="text-4xl font-bold text-slate-900">{leads.length}</div>
          <div className="text-green-500 text-sm font-semibold mt-2 flex items-center gap-1">
            <i className="fas fa-arrow-up"></i> 12% from last week
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
          <div className="text-slate-400 text-xs font-bold uppercase mb-2">Conv. Rate</div>
          <div className="text-4xl font-bold text-slate-900">4.2%</div>
          <div className="text-blue-500 text-sm font-semibold mt-2 flex items-center gap-1">
            <i className="fas fa-info-circle"></i> Above industry average
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
          <div className="text-slate-400 text-xs font-bold uppercase mb-2">Sync Status</div>
          <div className="text-4xl font-bold text-green-600">LIVE</div>
          <div className="text-slate-400 text-sm mt-2">Connected to Google Sheets</div>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-slate-100 shadow-xl overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-bottom border-slate-100">
            <tr>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Customer</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Email</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Date</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {leads.length === 0 ? (
              <tr>
                <td colSpan={4} className="px-6 py-20 text-center text-slate-400 italic">
                  No leads captured yet. Publish your page and start collecting!
                </td>
              </tr>
            ) : (
              leads.map((lead) => (
                <tr key={lead.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4 font-semibold text-slate-900">{lead.name}</td>
                  <td className="px-6 py-4 text-slate-600">{lead.email}</td>
                  <td className="px-6 py-4 text-slate-500 text-sm">{lead.timestamp}</td>
                  <td className="px-6 py-4">
                    <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold">Synced</span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Dashboard;
