
import React, { useState } from 'react';

interface LoginProps {
  onLogin: (password: string) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'admin123') { // Simple demo password
      onLogin(password);
    } else {
      setError(true);
      setTimeout(() => setError(false), 2000);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-100 px-6">
      <div className="bg-white p-10 rounded-[2.5rem] shadow-2xl w-full max-w-md border border-slate-200">
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-blue-600 rounded-3xl flex items-center justify-center text-white text-3xl mx-auto mb-4 shadow-xl shadow-blue-200">
            <i className="fas fa-user-shield"></i>
          </div>
          <h2 className="text-3xl font-black text-slate-900">Admin Login</h2>
          <p className="text-slate-500 mt-2">Masuk ke dashboard untuk mengelola gedung.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-xs font-bold text-slate-500 mb-2 uppercase tracking-widest">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={`w-full p-4 rounded-2xl border ${error ? 'border-red-500 bg-red-50' : 'border-slate-200'} outline-none focus:ring-2 focus:ring-blue-500 transition-all text-center text-xl tracking-widest`}
              placeholder="••••••••"
              required
            />
            {error && <p className="text-red-500 text-xs mt-2 text-center font-bold">Password salah!</p>}
          </div>

          <button
            type="submit"
            className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold text-lg hover:bg-blue-600 transition-all shadow-lg active:scale-95"
          >
            Masuk Sekarang
          </button>
        </form>
        
        <p className="text-center mt-8 text-slate-400 text-xs font-medium uppercase tracking-tighter">
          Gunakan password <span className="text-slate-900 font-bold">admin123</span> untuk demo.
        </p>
      </div>
    </div>
  );
};

export default Login;
