
import { GoogleGenAI, Type } from "@google/genai";

// Standard initialization with the process.env.API_KEY
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateBuildingDescription = async (buildingName: string, type: string): Promise<string> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Generate a short, elegant, and persuasive marketing description (max 2 sentences) for a building/venue named "${buildingName}" which is used as a ${type}.`,
  });

  return response.text || "A premium space for your next big event.";
};
