
import React, { useState, useEffect } from 'react';
import Navigation from './components/Navigation.tsx';
import Builder from './components/Builder.tsx';
import Preview from './components/Preview.tsx';
import Dashboard from './components/Dashboard.tsx';
import Settings from './components/Settings.tsx';
import Login from './components/Login.tsx';
import { ViewMode, Building, ScheduleItem, Booking, Settings as SettingsType } from './types.ts';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewMode>(ViewMode.LANDING);
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem('isAdmin') === 'true';
  });
  
  const [buildings, setBuildings] = useState<Building[]>([
    {
      id: 'B001',
      name: 'Grand Ballroom Sudirman',
      description: 'Ruangan mewah dengan desain kontemporer, cocok untuk pernikahan dan konferensi internasional.',
      imageUrl: 'https://images.unsplash.com/photo-1519167758481-83f550bb49b3?auto=format&fit=crop&q=80&w=800',
      capacity: 500,
      pricePerHour: 2500000
    },
    {
      id: 'B002',
      name: 'Aula Serbaguna Bina Karya',
      description: 'Fasilitas lengkap dengan sistem audio mutakhir dan parkir luas.',
      imageUrl: 'https://images.unsplash.com/photo-1431540015161-0bf868a2d407?auto=format&fit=crop&q=80&w=800',
      capacity: 200,
      pricePerHour: 1200000
    },
    {
      id: 'B003',
      name: 'Meeting Room Alpha',
      description: 'Privat dan tenang, ideal untuk rapat direksi atau workshop kecil.',
      imageUrl: 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=800',
      capacity: 25,
      pricePerHour: 450000
    }
  ]);

  const [schedules, setSchedules] = useState<ScheduleItem[]>([
    { id: 'S1', buildingId: 'B001', date: '2024-12-25', status: 'Booked' },
    { id: 'S2', buildingId: 'B001', date: '2024-12-26', status: 'Available' },
    { id: 'S3', buildingId: 'B002', date: '2024-12-25', status: 'Maintenance' },
    { id: 'S4', buildingId: 'B003', date: '2024-12-27', status: 'Available' }
  ]);

  const [bookings, setBookings] = useState<Booking[]>([]);

  const [settings, setSettings] = useState<SettingsType>({
    googleSheetWebhook: '',
    googleDriveFolderId: ''
  });

  const handleBooking = (newBooking: Booking) => {
    setBookings([newBooking, ...bookings]);
    if (settings.googleSheetWebhook) {
      console.log('Sending to Google Sheet:', newBooking);
    }
  };

  const handleLogin = (pass: string) => {
    setIsLoggedIn(true);
    localStorage.setItem('isAdmin', 'true');
    setCurrentView(ViewMode.BOOKINGS);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    localStorage.removeItem('isAdmin');
    setCurrentView(ViewMode.LANDING);
  };

  const renderView = () => {
    // Check if the current view is an admin view
    const isAdminView = [ViewMode.SCHEDULE_MANAGER, ViewMode.BOOKINGS, ViewMode.SETTINGS].includes(currentView);
    
    // Redirect to Login if accessing admin view without auth
    if (isAdminView && !isLoggedIn) {
      return <Login onLogin={handleLogin} />;
    }

    switch (currentView) {
      case ViewMode.LANDING:
        return <Preview buildings={buildings} schedules={schedules} onBook={handleBooking} />;
      case ViewMode.SCHEDULE_MANAGER:
        return <Builder buildings={buildings} setBuildings={setBuildings} schedules={schedules} setSchedules={setSchedules} />;
      case ViewMode.BOOKINGS:
        const leads = bookings.map(b => ({
          id: b.id,
          name: b.customerName,
          email: b.customerEmail,
          company: b.buildingName,
          timestamp: b.timestamp
        }));
        return <Dashboard leads={leads} />;
      case ViewMode.SETTINGS:
        return <Settings settings={settings} setSettings={setSettings} />;
      default:
        return <Preview buildings={buildings} schedules={schedules} onBook={handleBooking} />;
    }
  };

  return (
    <div className="min-h-screen">
      {renderView()}
      <Navigation 
        currentView={currentView} 
        setView={setCurrentView} 
        isLoggedIn={isLoggedIn} 
        onLogout={handleLogout}
      />
    </div>
  );
};

export default App;
