
export interface Building {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
  capacity: number;
  pricePerHour: number;
}

export interface ScheduleItem {
  id: string;
  buildingId: string;
  date: string;
  status: 'Available' | 'Booked' | 'Maintenance';
  notes?: string;
}

export interface Booking {
  id: string;
  customerName: string;
  customerEmail: string;
  buildingName: string;
  bookingDate: string;
  timestamp: string;
  status: 'Pending' | 'Confirmed';
}

/**
 * Represents a lead entity used in the dashboard, derived from customer bookings.
 */
export interface Lead {
  id: string;
  name: string;
  email: string;
  company?: string;
  timestamp: string;
}

export interface Settings {
  googleSheetWebhook: string;
  googleDriveFolderId: string;
}

export enum ViewMode {
  LANDING = 'landing',
  SCHEDULE_MANAGER = 'manager',
  BOOKINGS = 'bookings',
  SETTINGS = 'settings'
}
